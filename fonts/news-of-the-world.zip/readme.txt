Font: News of the World (Regular, Italic, Wide, Wide Italic)
Version: 1.0
Dennis Ludlow 2015 all rights reserved
Sharkshock Productions
dennis@sharkshock.net


EXTRA!! EXTRA!! Read all about it! Thanks for having a look at my latest typeface; News of the World. It features broad, strong, characters that appear to have come right off a magazine, sports
blog, or newspaper. This style demands emphasis and is sure to grab your audience's attention. 4 different styles give your works some variety. Try Regular in all caps for an eye catching
headline or wide italic for a company logo. The next time you're thinking of using Impact give this font a try.  

News of the World contains basic latin, extended latin, various ligatures, Eastern European accents, kerning, and full punctuation. You can produce the globe on the regular version by keying the 
rarely used infinity symbol. This font like my others are free for personal use only as long as this readme file stays intact. For commercial use please contact me at dennis@sharkshock.net to 
discuss an end user license. I also design custom fonts for businesses, logos, and many other things. If you'd like to leave me a donation you can use the same address via paypal. Your generosity 
will be most appreciated! Enjoy!


visit www.sharkshock.net for more and take a bite out of BORING design!

